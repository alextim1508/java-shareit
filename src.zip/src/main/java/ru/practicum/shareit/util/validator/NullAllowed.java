package ru.practicum.shareit.util.validator;

public interface NullAllowed {
}

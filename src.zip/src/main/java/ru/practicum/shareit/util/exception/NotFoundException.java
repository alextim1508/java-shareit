package ru.practicum.shareit.util.exception;


public class NotFoundException extends RuntimeException {

    public NotFoundException(String message) {
        super(message);
    }

    public NotFoundException(Class c) {
        super("");
    }
}

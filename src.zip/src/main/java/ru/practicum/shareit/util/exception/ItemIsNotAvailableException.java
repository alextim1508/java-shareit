package ru.practicum.shareit.util.exception;

public class ItemIsNotAvailableException extends RuntimeException {
    public ItemIsNotAvailableException() {
        super();
    }
}

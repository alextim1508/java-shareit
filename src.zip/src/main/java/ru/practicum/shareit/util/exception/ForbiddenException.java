package ru.practicum.shareit.util.exception;

public class ForbiddenException extends RuntimeException {
    public ForbiddenException() {
        super();
    }
}

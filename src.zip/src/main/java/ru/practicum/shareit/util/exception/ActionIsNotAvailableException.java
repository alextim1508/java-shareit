package ru.practicum.shareit.util.exception;

public class ActionIsNotAvailableException extends RuntimeException {
    public ActionIsNotAvailableException() {
        super();
    }
}

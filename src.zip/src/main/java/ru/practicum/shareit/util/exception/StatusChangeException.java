package ru.practicum.shareit.util.exception;

public class StatusChangeException extends RuntimeException {
    public StatusChangeException() {
        super();
    }
}

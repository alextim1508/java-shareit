package ru.practicum.shareit.user.model;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class UserTest {

    @Test
    void testEquals_Symmetric() {
        User x = new User(1, "user", "user@gmail.com");
        User y = new User(2, "user", "user@gmail.com");

        assertThat(x.equals(y) && y.equals(x)).isTrue();
        assertThat(x.hashCode() == y.hashCode()).isTrue();
    }
}

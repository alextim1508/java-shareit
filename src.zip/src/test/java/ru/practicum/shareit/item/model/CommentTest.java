package ru.practicum.shareit.item.model;

import org.junit.jupiter.api.Test;
import ru.practicum.shareit.user.model.User;

import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

public class CommentTest {

    @Test
    void testEquals_Symmetric() {
        User owner = User.builder()
                .id(1)
                .name("owner")
                .email("owner@gmail.com")
                .build();

        Item item = Item.builder()
                .name("item")
                .description("description")
                .available(true)
                .owner(owner)
                .build();

        User author = User.builder()
                .id(2)
                .name("author")
                .email("author@gmail.com")
                .build();
        LocalDateTime now = LocalDateTime.now();

        Comment x = new Comment(1, "comment", item, author, now);
        Comment y = new Comment(2, "comment", item, author, now);


        assertThat(x.equals(y) && y.equals(x)).isTrue();
        assertThat(x.hashCode() == y.hashCode()).isTrue();
    }
}

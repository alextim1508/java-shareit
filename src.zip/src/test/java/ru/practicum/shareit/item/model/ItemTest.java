package ru.practicum.shareit.item.model;

import org.junit.jupiter.api.Test;
import ru.practicum.shareit.user.model.User;

import static org.assertj.core.api.Assertions.assertThat;

public class ItemTest {

    @Test
    void testEquals_Symmetric() {
        User owner = User.builder()
                .id(1)
                .name("owner")
                .email("owner@gmail.com")
                .build();

        Item x = Item.builder()
                .name("item")
                .description("description")
                .available(true)
                .owner(owner)
                .build();

        Item y = Item.builder()
                .name("item")
                .description("description")
                .available(true)
                .owner(owner)
                .build();

        assertThat(x.equals(y) && y.equals(x)).isTrue();
        assertThat(x.hashCode() == y.hashCode()).isTrue();
    }

}
